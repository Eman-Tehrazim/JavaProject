package bank.management.system;

import bank.management.system.classes.TransactionProcessor;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import java.awt.*;

// Handles transaction processing and balance calculations

public final class Statement extends JFrame {

    private final TransactionProcessor transactionProcessor;

    public Statement() {
        super("Banking Management System");

        // Initialize the transaction processor with the file path
        transactionProcessor = new TransactionProcessor("Deposit.txt");
        transactionProcessor.processTransactions();

        // Display the final statement
        displayStatement();
    }

    // Method to display the final statement with all transaction details
    private void displayStatement() {
        double balance = transactionProcessor.getBalance();
        List<String> transactionHistory = transactionProcessor.getTransactionHistory();

        StringBuilder statement = new StringBuilder();
        statement.append("Your current balance is: Rs ").append(balance).append("\n\n");
        statement.append("Transaction History:\n");
        for (String transaction : transactionHistory) {
            statement.append(transaction).append("\n");
        }

        // Displaying the statement as a dialog box
        JOptionPane.showMessageDialog(this, statement.toString(), "Transaction Statement", JOptionPane.INFORMATION_MESSAGE);

        // Close the current frame and open the Employee page
        setVisible(false);
        new Employee1();
    }

    public static void main(String[] args) {
        new Statement().setVisible(true);
    }
}