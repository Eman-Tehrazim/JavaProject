package bank.management.system;
import javax.swing.*;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*;


public class Employee1 extends JFrame implements ActionListener {
    
   Employee1() {
       
       
       getContentPane().setBackground(Color.WHITE);
       setLayout(null);
       
       //Picture
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/bank.jpg"));
       Image i2 = i1.getImage().getScaledInstance(900, 620, Image.SCALE_DEFAULT);
       ImageIcon i3= new ImageIcon(i2);  //convert into image icon why?
       JLabel image = new JLabel (i3); //Because image should be pass in Jlabel.Image class object cannot pass through jlabel so conerted to image icon
       image.setBounds(0 ,0 ,900 ,620);
       add(image);//we cannot add object of immage icon directly so we made Jlabel where we add i3 
       
       
       
       //Button
       JButton clickhere = new JButton("CLICK HERE TO CONTINUE"); //Jbutton class to add button
       clickhere.setBounds(300, 500 , 300, 60);//1st left and right 2nd upper lower 3rd length and 4th width
       clickhere.setFont(new Font("serif", Font.BOLD , 20));
       clickhere.addActionListener(this); 
       image.add(clickhere); //To add button on image then call it from that element that is "image"
       
       
       //Heading
       JLabel heading = new JLabel("EMPLOYEE MANAGEMENT SYSTEM");
       heading.setBounds(95, 30, 1200, 60);
       heading.setFont(new Font("serif", Font.BOLD , 40));
       heading.setForeground(Color.BLACK);
       image.add(heading);
       
       
       
        setSize(900, 620);
        setLocation(250, 80);
       setVisible(true); //Just not for frames but To hide elements 
   }

    Employee1(String name, String fname, String dob, String salary, String address, String phone, String email, String education, String designation, String cnic, String empid) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
   public void actionPerformed(ActionEvent ae){
     setVisible(false); //current Frame close
     new employeepage(); //opens home page
   }
   
   
   public static void main(String args[]) {
       new Employee1();
   }

    void saveToFile() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
}