package bank.management.system;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import java.awt.event.*;

public class Transaction extends JFrame implements ActionListener {
    
    JButton exit, deposit, withdraw, fast, check, statement, pin;
    Transaction(){
        super("Banking Management System");
      

        // Image setup for background
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/g.jpg"));
        Image i2 = i1.getImage().getScaledInstance(720, 620, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 720, 620);
        add(image);
        
        JLabel text = new JLabel("WELCOME TO ATM");
        text.setFont(new Font("CASTELLAR", Font.BOLD, 30));
        text.setBounds(130, 105, 750, 50);
        text.setForeground(Color.BLACK);
        image.add(text);

        // Adding labels and text fields
        JLabel persdeta = new JLabel("Please Select Your Transaction");
        persdeta.setFont(new Font("RALEWAY", Font.PLAIN, 16));
        persdeta.setBounds(150, 140, 750, 50);
        persdeta.setForeground(Color.DARK_GRAY);
        image.add(persdeta);

        deposit = new JButton("Deposit");
        deposit.setBounds(180, 240, 100, 30);
        deposit.addActionListener(this);
        image.add(deposit);
        
        withdraw = new JButton("Withdrawal");
        withdraw.setBounds(320, 240, 115, 30);
        withdraw.addActionListener(this);
        image.add(withdraw);
        
        fast = new JButton("Fast Cash");
        fast.setBounds(180, 290, 100, 30);
        fast.addActionListener(this);
        image.add(fast);
        
        statement = new JButton("E-Statement");
        statement.setBounds(320, 290, 115, 30);
        statement.addActionListener(this);
        image.add(statement);
        
        check = new JButton("Check Balance");
        check.setBounds(315, 340, 120, 30);
        check.addActionListener(this);
        image.add(check);
        
        pin = new JButton("Pin Change");
        pin.setBounds(180, 340, 100, 30);
        pin.addActionListener(this);
        image.add(pin);
        
        exit = new JButton("EXIT");
        exit.setBounds(500, 530, 100, 30);
        exit.addActionListener(this);
        image.add(exit);

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);    
        setSize(720, 620);
        setLocation(300, 100);
        setUndecorated(true);
        setVisible(true);     
    }
    @Override
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()== exit){
            System.exit(0); // terminate from currently running program
        }
        else if(ae.getSource()== deposit){
            setVisible(false);
            new Deposit().setVisible(true);
        }
        else if(ae.getSource()== withdraw){
            setVisible(false);
            new Withdraw().setVisible(true);
        }
        else if(ae.getSource() == fast){
            setVisible(false);
            new Fast().setVisible(true);
        }
        else if(ae.getSource() == pin){
            setVisible(false);
            new pinChange().setVisible(true);
        }
        else if(ae.getSource() == check){
            setVisible(false);
            new checkBalance().setVisible(true);
        }
        else if(ae.getSource() == statement){
            setVisible(false);
            new Statement().setVisible(true);
        }
    }
    public static void main(String[]args){
        new Transaction();
    }
}
       