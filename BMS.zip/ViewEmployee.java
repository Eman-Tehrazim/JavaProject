package bank.management.system;

import bank.management.system.classes.IEmployeeOperations;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.Color;
import java.awt.Font;
import java.awt.event.*;
import java.io.*;
import java.text.SimpleDateFormat;

// Interface for Employee Operations


// Main class implementing EmployeeOperations and ActionListener
// inheritence
public class ViewEmployee extends JFrame implements IEmployeeOperations, ActionListener {

    private JTable table;
    private JButton print, update, back;
    private DefaultTableModel model;

    public ViewEmployee() {
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // Table setup
        String[] columnNames = {"Name", "Father's Name", "DOB", "Salary", "Address", "Phone", "Email", "Education", "Designation", "CNIC", "Emp ID"};
        model = new DefaultTableModel(columnNames, 0);
        table = new JTable(model);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(15, 20, 1050, 400);
        add(sp);

        // Load employee data
        loadEmployeeData();

        // Buttons setup
        back = createButton("Back", 220, 450, this);
        update = createButton("Update", 470, 450, this);
        print = createButton("Print", 730, 450, this);

        setSize(1100, 600);
        setLocation(150, 70);
        setVisible(true);
    }

    private JButton createButton(String text, int x, int y, ActionListener listener) {
        JButton button = new JButton(text);
        button.setBounds(x, y, 150, 50);
        button.setFont(new Font("SERIF", Font.BOLD, 25));
        button.addActionListener(listener);
        add(button);
        return button;
    }

    @Override
    public void loadEmployeeData() {
        model.setRowCount(0); // Clear the table

        try (BufferedReader br = new BufferedReader(new FileReader("employeeDetails.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] rowData = line.split(", ");
                if (rowData.length == 11) {
                    model.addRow(rowData);
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error loading employee data: " + e.getMessage());
        }
    }

    @Override
    public void saveTableData() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("employeeDetails.txt"))) {
            for (int i = 0; i < model.getRowCount(); i++) {
                StringBuilder sb = new StringBuilder();
                for (int j = 0; j < model.getColumnCount(); j++) {
                    sb.append(model.getValueAt(i, j));
                    if (j < model.getColumnCount() - 1) sb.append(", ");
                }
                bw.write(sb.toString());
                bw.newLine();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving employee data: " + e.getMessage());
        }
    }

    @Override
    public boolean validateInput(String field, String value) {
        switch (field) {
            case "Salary":
                return value.matches("\\d+");
            case "Phone":
                return value.matches("\\d{11}");
            case "Email":
                return value.matches("^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");
            case "CNIC":
                return value.matches("\\d{5}-\\d{7}-\\d{1}");
            case "DOB":
                return isValidDate(value);
            default:
                return !value.trim().isEmpty(); // Default validation for non-empty fields
        }
    }

    private boolean isValidDate(String dateStr) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        sdf.setLenient(false);
        try {
            sdf.parse(dateStr);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private int getColumnIndex(String fieldToUpdate) {
        switch (fieldToUpdate) {
            case "Name":
                return 0;
            case "Father's Name":
                return 1;
            case "DOB":
                return 2;
            case "Salary":
                return 3;
            case "Address":
                return 4;
            case "Phone":
                return 5;
            case "Email":
                return 6;
            case "Education":
                return 7;
            case "Designation":
                return 8;
            case "CNIC":
                return 9;
            case "Emp ID":
                return 10;
            default:
                return -1; // Invalid field
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == print) {
            try {
                table.print();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Error printing table: " + e.getMessage());
            }
        } else if (ae.getSource() == update) {
            int selectedRow = table.getSelectedRow();
            if (selectedRow == -1) {
                JOptionPane.showMessageDialog(this, "Please select a row to update.");
                return;
            }

            // Polymorphic behavior for updating fields
            String[] options = {"Name", "Father's Name", "DOB", "Salary", "Address", "Phone", "Email", "Education", "Designation", "CNIC", "Emp ID"};
            String fieldToUpdate;
            fieldToUpdate = (String) JOptionPane.showInputDialog(this, "Choose field to update:", "Update Field",
                    JOptionPane.QUESTION_MESSAGE, null, options, options[0]);

            if (fieldToUpdate != null) {
                int colIndex = getColumnIndex(fieldToUpdate);
                String currentValue = model.getValueAt(selectedRow, colIndex).toString();
                String newValue = JOptionPane.showInputDialog(this, "Update " + fieldToUpdate, currentValue);

                if (newValue != null && validateInput(fieldToUpdate, newValue)) {
                    model.setValueAt(newValue, selectedRow, colIndex);
                    JOptionPane.showMessageDialog(this, fieldToUpdate + " updated successfully.");
                    saveTableData();
                } else {
                    JOptionPane.showMessageDialog(this, "Invalid input for " + fieldToUpdate + ".");
                }
            }
        } else if (ae.getSource() == back) {
            setVisible(false);
            new employeepage(); // Assume EmployeePage is another class
        }
    }

    public static void main(String[] args) {
        new ViewEmployee();
    }
}