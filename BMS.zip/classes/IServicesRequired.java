/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank.management.system.classes;

/**
 *
 * @author 3tee
 */
public interface IServicesRequired {
    String getServicesRequired();
}
