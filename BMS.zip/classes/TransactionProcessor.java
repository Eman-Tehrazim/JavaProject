/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank.management.system.classes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author 3tee
 */
public class TransactionProcessor {
    private final String filePath;
    private double balance;
    private final List<String> transactionHistory;

    public TransactionProcessor(String filePath) {
        this.filePath = filePath;
        this.balance = 0.0;
        this.transactionHistory = new ArrayList<>();
    }

    // Reads transactions from the file and calculates the balance
    public void processTransactions() {
        File file = new File(filePath);

        // Check if the file exists
        if (!file.exists()) {
            System.err.println("Transaction file not found: " + filePath);
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Amount Deposited")) {
                    processDeposit(line);
                } else if (line.startsWith("Amount Withdrawn")) {
                    processWithdrawal(line);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading transaction file: " + e.getMessage());
        }
    }

    // Processes a deposit transaction and updates the balance
    private void processDeposit(String line) {
        String[] parts = line.split(":");
        String amountStr = parts[1].split(",")[0].trim();
        try {
            double amount = Double.parseDouble(amountStr);
            balance += amount;
            transactionHistory.add("Deposited Rs " + amount + " | Balance: Rs " + balance);
        } catch (NumberFormatException e) {
            System.err.println("Invalid deposit amount: " + amountStr);
        }
    }

    // Processes a withdrawal transaction and updates the balance
    private void processWithdrawal(String line) {
        String[] parts = line.split(":");
        String amountStr = parts[1].split(",")[0].trim();
        try {
            double amount = Double.parseDouble(amountStr);
            if (amount > balance) {
                transactionHistory.add("Withdrawal of Rs " + amount + " failed due to insufficient funds. | Balance: Rs " + balance);
            } else {
                balance -= amount;
                transactionHistory.add("Withdrawn Rs " + amount + " | Balance: Rs " + balance);
            }
        } catch (NumberFormatException e) {
            System.err.println("Invalid withdrawal amount: " + amountStr);
        }
    }

    // Get the final balance
    public double getBalance() {
        return balance;
    }

    // Get the transaction history
    public List<String> getTransactionHistory() {
        return new ArrayList<>(transactionHistory); // Return a copy to ensure encapsulation
    }
}