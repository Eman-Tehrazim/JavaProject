/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank.management.system.classes;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author 3tee
 */
public class EmployeeClass extends EmployeeEntityClass{
    private String name;
    private String fatherName;
    private String dob;
    private String salary;
    private String address;
    private String phone;
    private String email;
    private String education;
    private String designation;
    private String cnic;
    private String empId;

    // Constructor overloading
    public EmployeeClass(String name, String fatherName, String dob, String salary, String address,
                    String phone, String email, String education, String designation, String cnic, String empId) {
        super(name, phone, email, empId);
        //this.name = name;
        this.fatherName = fatherName;
        this.dob = dob;
        this.salary = salary;
        this.address = address;
        //this.phone = phone;
        //this.email = email;
        this.education = education;
        this.designation = designation;
        this.cnic = cnic;
        //this.empId = empId;
    }

    EmployeeClass() {
        super("", "", "", "");
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    // Method to save employee details to file
    public void saveToFile() throws IOException {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("employeeDetails.txt", true))) {
            bw.write(name + ", " + fatherName + ", " + dob + ", " + salary + ", " + address + ", " +
                     phone + ", " + email + ", " + education + ", " + designation + ", " + cnic + ", " + empId);
            bw.newLine();
        }
    }
}