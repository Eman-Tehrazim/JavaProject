/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank.management.system.classes;

/**
 *
 * @author 3tee
 */
public class EmployeeEntityClass {
 
    private String name;
    private String phone;
    private String email;
    private String empID;

    public EmployeeEntityClass(String name, String phone, String email, String empID) {
        this.name = name;
        this.phone = phone;
        this.email = email;
        this.empID = empID;
    }

    // Getters
    public String getName() {
        return name;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getEmpID() {
        return empID;
    }

    
}
