package bank.management.system;
import javax.swing.*;
import java.awt.*;
import java.awt.Image;
import java.awt.event.*;

public class employeepage extends JFrame implements ActionListener { // jframe is parent class
    
    
    JButton view ,  add , update , remove;
    
    employeepage() {
        
       setLayout(null);
        
        
       //Image
       ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/3.jpg"));
       Image i2 = i1.getImage().getScaledInstance(900, 620, Image.SCALE_DEFAULT);
       ImageIcon i3= new ImageIcon(i2); 
       JLabel image = new JLabel (i3); 
       image.setBounds(0 ,0 ,900 ,620);
       add(image);
        
       
       //Heading
       JLabel heading = new JLabel ("Employee Management System");
       heading.setBounds(125, 20 ,1000 , 80);
       heading.setFont(new Font("serif", Font.BOLD, 45));
       heading.setForeground(Color.WHITE);
       image.add(heading);
       
       
       
       //BUTTONS
       add = new JButton("Add Employee");
       add.setBounds(180, 140 , 200, 50 ); //300 (right left), 200 (width) , 140 (up and down) , 50 (smaller bigger)
       add.setFont(new Font("Serif", Font.PLAIN , 20));
       add.addActionListener(this);
       image.add(add);
       
       view = new  JButton("View Employees");
       view.setBounds(480 , 140 , 200, 50 );
       view.setFont(new Font("Serif", Font.PLAIN , 20));
       view.addActionListener(this);
       image.add(view);
       
       update = new JButton("Update Employee");
       update.setBounds(180, 220 , 200, 50 );
       update.setFont(new Font("Serif", Font.PLAIN  , 20));
       update.addActionListener(this);
       image.add(update);
       
       remove= new JButton("Remove Employee");
       remove.setBounds(480, 220 , 200, 50 );
       remove.setFont(new Font("Serif", Font.PLAIN  , 20));
       remove.addActionListener(this);
       image.add(remove);
       
       
       
       //Page Size
        setSize(900, 620); //pagesize 1100 is width 700 is height
        setLocation(220,80);
        setVisible(true);
    }
    
  
    public void actionPerformed(ActionEvent ae){ //for button listeners
     
         if (ae.getSource() == add ){
             
             setVisible(false); //current Frame close
             new AddEmployee(); //opens home page 
        
        } else if (ae.getSource() == view ){
            
            setVisible(false); 
            new ViewEmployee(); 
            
        } else if (ae.getSource() == update){
            setVisible(false); 
            new ViewEmployee();
            
        } else if (ae.getSource() == remove){
            setVisible(false); 
            new DeleteEmployee();
        }
               
        }
  
    public static void main(String[] args){
       new employeepage();
    }
    
}