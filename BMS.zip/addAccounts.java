package bank.management.system;
import bank.management.system.classes.AccountClass;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;


// Main GUI Class
public class addAccounts extends JFrame implements ActionListener {
    Random ran = new Random();
    int number = ran.nextInt(999999); // Random Account ID

    JTextField t1name, tfname, tfaddress, tfphone, tfcnic, tfemail, tfsalary, tfdesignation, t2name;
    JComboBox<String> cbeducation;
    JLabel lblaccid;
    JButton add, back;

    addAccounts() {
        super("Banking Management System");

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/f.jpg"));
        Image i2 = i1.getImage().getScaledInstance(700, 600, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(1, 1, 700, 570);
        add(image);

        
        JLabel text = new JLabel("ADD ACCOUNT DETAILS");
        text.setFont(new Font("CASTELLAR", Font.BOLD, 30));
        text.setBounds(125, 20, 750, 50);
        text.setForeground(Color.WHITE);
        image.add(text);

       
        JLabel name = new JLabel("First Name: ");
        name.setFont(new Font("RALEWAY", Font.BOLD, 15));
        name.setBounds(130, 100, 570, 30);
        name.setForeground(Color.WHITE);
        image.add(name);
        
        t1name = new JTextField();
        t1name.setBounds(255, 100, 290, 25);
        t1name.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(t1name);
        
        JLabel fname = new JLabel("Last Name: ");
        fname.setFont(new Font("RALEWAY", Font.BOLD, 15));
        fname.setBounds(130, 140, 570, 30);
        fname.setForeground(Color.WHITE);
        image.add(fname);
        
        t2name = new JTextField();
        t2name.setBounds(255, 140, 290, 25);
        t2name.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(t2name);

     
        JLabel dob = new JLabel("Father Name: ");
        dob.setFont(new Font("RALEWAY", Font.BOLD, 15));
        dob.setBounds(130, 180, 570, 30);
        dob.setForeground(Color.WHITE);
        image.add(dob);
        
        tfname = new JTextField();
        tfname.setBounds(255, 180, 290, 25);
        tfname.setFont(new Font("Ariel", Font.BOLD, 15));
        image.add(tfname);

     
        JLabel salary = new JLabel("Salary: ");
        salary.setFont(new Font("RALEWAY", Font.BOLD, 15));
        salary.setBounds(130, 220, 570, 30);
        salary.setForeground(Color.WHITE);
        image.add(salary);
        
        tfsalary = new JTextField();
        tfsalary.setBounds(255, 220, 290, 25);
        tfsalary.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(tfsalary);
      
        JLabel address = new JLabel("Address: ");
        address.setFont(new Font("RALEWAY", Font.BOLD, 15));
        address.setBounds(130, 260, 570, 30);
        address.setForeground(Color.WHITE);
        image.add(address);
        
        tfaddress = new JTextField();
        tfaddress.setBounds(255, 260, 290, 25);
        tfaddress.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(tfaddress);
        
        JLabel phoneno = new JLabel("Phone Number: ");
        phoneno.setFont(new Font("RALEWAY", Font.BOLD, 15));
        phoneno.setBounds(130, 300, 570, 30);
        phoneno.setForeground(Color.WHITE);
        image.add(phoneno);
        
        tfphone = new JTextField();
        tfphone.setBounds(255, 300, 290, 25);
        tfphone.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(tfphone);
        
        JLabel email = new JLabel("Email Address: ");
        email.setFont(new Font("RALEWAY", Font.BOLD, 15));
        email.setBounds(130, 340, 570, 30);
        email.setForeground(Color.WHITE);
        image.add(email);
        
        tfemail = new JTextField();
        tfemail.setBounds(255, 340, 290, 25);
        tfemail.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(tfemail);

        JLabel labeleducation = new JLabel("Education:");
        labeleducation.setBounds(130, 380, 570, 30);
        labeleducation.setForeground(Color.WHITE);
        labeleducation.setFont(new Font("RALEWAY", Font.BOLD, 15));
        image.add(labeleducation);
        
        String[] courses = {"BSSE", "BCA", "B.COM", "BSSC", "BA", "BTech", "MBA", "MCA", "MA", "MSC", "PHD"};
        cbeducation = new JComboBox(courses);
        cbeducation.setBackground(Color.WHITE);
        cbeducation.setBounds(255, 380, 290, 25);
        image.add(cbeducation);

        JLabel labeldesignation = new JLabel("Designation:");
        labeldesignation.setBounds(130, 420, 570, 30);
        labeldesignation.setForeground(Color.WHITE);
        labeldesignation.setFont(new Font("RALEWAY", Font.BOLD, 15));
        image.add(labeldesignation);
        
        tfdesignation = new JTextField();
        tfdesignation.setBounds(255, 420, 290, 25);
        tfdesignation.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(tfdesignation);
        
        JLabel labelcnic = new JLabel("CNIC Number:");
        labelcnic.setBounds(130, 460, 570, 30);
        labelcnic.setForeground(Color.WHITE);
        labelcnic.setFont(new Font("RALEWAY", Font.BOLD, 15));
        image.add(labelcnic);
        
        tfcnic = new JTextField();
        tfcnic.setBounds(255, 460, 290, 25);
        tfcnic.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(tfcnic);

        JLabel lblaccid = new JLabel("Account ID: "+number);
        lblaccid.setBounds(130, 490, 570, 30);
        lblaccid.setForeground(Color.WHITE);
        lblaccid.setFont(new Font("RALEWAY", Font.BOLD, 15));
        image.add(lblaccid);
        
        add = new JButton("ADD");
        add.setBounds(450, 520, 100, 35);
        add.addActionListener(this);
        image.add(add);

        back = new JButton("BACK");
        back.setBounds(250, 520, 100, 35);
        back.addActionListener(this);
        image.add(back);

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setSize(710, 600);
        setLocation(300, 100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add) {
            String firstName = t1name.getText();
            String lastName = t2name.getText();
            String fatherName = tfname.getText();
            String salary = tfsalary.getText();
            String address = tfaddress.getText();
            String phone = tfphone.getText();
            String email = tfemail.getText();
            String education = (String) cbeducation.getSelectedItem();
            String designation = tfdesignation.getText();
            String cnic = tfcnic.getText();
            String accountId = number+"";
          

            if (!validateInput(firstName, lastName, fatherName, salary, address, phone, email, cnic)) {
                //JOptionPane.showMessageDialog(null, "Account Details not added");
                return; // Validation failed
            }

            // Create Account object and save details
            AccountClass account = new AccountClass(firstName, lastName, fatherName, salary, address, phone, email, education, designation, cnic, accountId);
            account.saveToFile();
            JOptionPane.showMessageDialog(null, "Account Details Added Successfully");
            setVisible(false);
            new viewAccount(); // Navigate to next screen
        } else if (ae.getSource() == back) {
            setVisible(false);
        }
    }

    private boolean validateInput(String firstName, String lastName, String fatherName, String salary, String address, String phone, String email, String cnic) {
        if (firstName.isEmpty() || lastName.isEmpty() || fatherName.isEmpty() || salary.isEmpty() || address.isEmpty() || phone.isEmpty() || email.isEmpty() || cnic.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields are required.");
            return false;
        }

        if (!firstName.matches("[a-zA-Z]+") || !lastName.matches("[a-zA-Z]+") || !fatherName.matches("[a-zA-Z]+")) {
            JOptionPane.showMessageDialog(null, "Name fields should only contain alphabets.");
            return false;
        }

        try {
            double salaryValue = Double.parseDouble(salary);
            if (salaryValue <= 0) {
                JOptionPane.showMessageDialog(null, "Salary must be a positive number.");
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Salary must be a valid number.");
            return false;
        }

        if (!phone.matches("[0-9]{11}")) {
            JOptionPane.showMessageDialog(null, "Phone number must be 11 digits.");
            return false;
        }

        if (!email.matches("^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$")) {
            JOptionPane.showMessageDialog(null, "Please enter a valid email address.");
            return false;
        }

        if (!cnic.matches("[0-9]{13}")) {
            JOptionPane.showMessageDialog(null, "CNIC must be 13 digits.");
            return false;
        }

        return true;
    }

    public static void main(String[] args) {
        new addAccounts();
    }
}