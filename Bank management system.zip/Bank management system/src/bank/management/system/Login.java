package bank.management.system;
import java.awt.Color; // abstract window tool kit
import java.awt.Font;
import java.awt.Image;
import java.awt.event.*; // for action listener 
import java.io.File; // file handling for 
import java.io.FileNotFoundException; // exception handling handle error/ exception handle
import java.util.Scanner; 
import javax.swing.*; // visiblity of all data on gui / building gui

public class Login extends JFrame implements ActionListener {
    // Using extends allows you to build class hierarchies
    JButton login, signup, clear;
    JTextField cardTextField;
    JPasswordField pinTextField; // to set the security of the pin (not visible to user)
    
    Login() { 
        super("Banking Management System"); // it is used to call the parent class(jframe) to set the title there
        
        // these have build in function 
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/acc.jpg"));
        Image i2 = i1.getImage().getScaledInstance(800, 450, Image.SCALE_DEFAULT); // to set the width and length of the image 
        ImageIcon i3 = new ImageIcon(i2); // these type of classes are used to build gui through swing component 
        JLabel image = new JLabel(i3); // swing component have all these classes 
        image.setBounds(1, 1, 800, 450);
        add(image); 
        
        JLabel text = new JLabel("AUTHENTICATOR"); 
        text.setFont(new Font("CASTELLAR", Font.BOLD, 38));
        text.setBounds(25, 20, 400, 40); // location from sides(left/right + upper/lower) + length and width
        text.setForeground(Color.DARK_GRAY);
        image.add(text);
        
        // Card number label and text field
        JLabel cardno = new JLabel("CARD NO: ");
        cardno.setFont(new Font("Raleway", Font.BOLD, 28));
        cardno.setBounds(50, 105, 400, 40);
        cardno.setForeground(Color.DARK_GRAY);
        image.add(cardno);
        // textfield
        cardTextField = new JTextField();
        cardTextField.setBounds(200, 107, 310, 35);
        cardTextField.setFont(new Font("Ariel", Font.BOLD, 14));
        image.add(cardTextField);
        
        // PIN label and password field
        JLabel pin = new JLabel("PIN: ");
        pin.setFont(new Font("Raleway", Font.BOLD, 28));
        pin.setBounds(50, 175, 400, 40);
        pin.setForeground(Color.DARK_GRAY);
        image.add(pin);
        // textfield
        pinTextField = new JPasswordField();
        pinTextField.setBounds(200, 177, 310, 35);
        image.add(pinTextField);
        
        // Sign in button
        login = new JButton("SIGN IN");
        login.setBounds(220, 265, 100, 30);
        login.addActionListener(this);
        image.add(login);
        
        // Clear button
        clear = new JButton("CLEAR");
        clear.setBounds(385, 265, 100, 30);
        clear.addActionListener(this);
        image.add(clear);
        
        // Sign up button
        signup = new JButton("SIGN UP");
        signup.setBounds(300, 315, 100, 30);
        signup.addActionListener(this);
        image.add(signup);
        
        // Frame settings
        setLayout(null); // to change own its own
        getContentPane().setBackground(Color.WHITE);
        setSize(800, 450);
        setLocation(300, 150);
        setVisible(true); 
    }

    @Override // parent classes ka method ko override kr rha hai
    public void actionPerformed(ActionEvent ae) { // event handling method (to trigger the buttons)
        if (ae.getSource() == clear) {
            // Clear card number and PIN fields
            cardTextField.setText("");
            pinTextField.setText("");
        } 
        else if (ae.getSource() == login) {
          String cardNumber = cardTextField.getText();
          String pin = new String(pinTextField.getPassword());
        
        if (cardNumber.isEmpty() || pin.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter both card number and PIN!");
            return;
        }
        try {
            File file = new File("Signup3.txt");
            Scanner scanner = new Scanner(file);
            // to read data from the file and match it
            boolean found = false;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine(); 
                if (line.contains("Card Number: " + cardNumber)) {
                    found = true; //The Scanner is reading each line in the file to check for specific information
                    while (scanner.hasNextLine()) {
                        line = scanner.nextLine();
                        if (line.contains("PIN: " + pin)) {
                            found = true;
                            JOptionPane.showMessageDialog(null, "Login successful!");
                            // You can add code here to navigate to the next screen
                            break;
                        }
                    }
                }
            }
            if (!found) {
                JOptionPane.showMessageDialog(null, "Invalid card number or PIN!");
            }
            setVisible(false);
            new Transaction().setVisible(true);
            scanner.close();
            
            } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "Error reading file: " + e.getMessage());
        }
        }else if (ae.getSource() == signup){
         new Signup1();
        }
    } public static void main(String[] args) {
        new Login();
    }
}
