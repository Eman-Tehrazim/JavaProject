package bank.management.system;

import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;

// Handles transaction-related operations
class TransactionHandler {
    private final String transactionFilePath;

    public TransactionHandler(String transactionFilePath) {
        this.transactionFilePath = transactionFilePath;
        ensureFileExists();
    }

    // Ensure the transaction file exists
    private void ensureFileExists() {
        File file = new File(transactionFilePath);
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error creating transaction file: " + e.getMessage());
        }
    }

    // Record a deposit transaction
    public boolean recordDeposit(double amount) {
        try (FileWriter writer = new FileWriter(transactionFilePath, true)) {
            String transaction = "Amount Deposited: " + amount + ", Date: " + new Date().toString() + "\n";
            writer.write(transaction);
            return true;
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing to transaction file: " + e.getMessage());
            return false;
        }
    }
}

public class Deposit extends JFrame implements ActionListener {
    JTextField amountField;
    JButton exitButton, depositButton;
    TransactionHandler transactionHandler;

    public Deposit() {
        super("Banking Management System");

        // Initialize the transaction handler
        transactionHandler = new TransactionHandler("Deposit.txt");

        // Background image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/g.jpg"));
        Image i2 = i1.getImage().getScaledInstance(720, 620, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 720, 620);
        add(image);

        // Heading label
        JLabel text = new JLabel("ENTER THE AMOUNT YOU WANT TO DEPOSIT");
        text.setFont(new Font("CASTELLAR", Font.PLAIN, 14));
        text.setBounds(127, 125, 750, 50);
        text.setForeground(Color.BLACK);
        image.add(text);

        // Amount input field
        amountField = new JTextField();
        amountField.setBounds(195, 270, 220, 25);
        amountField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(amountField);

        // Deposit button
        depositButton = new JButton("DEPOSIT");
        depositButton.setBounds(315, 325, 100, 35);
        depositButton.addActionListener(this);
        image.add(depositButton);

        // Exit button
        exitButton = new JButton("EXIT");
        exitButton.setBounds(195, 325, 80, 35);
        exitButton.addActionListener(this);
        image.add(exitButton);

        // Window properties
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setSize(720, 620);
        setLocation(300, 100);
        setUndecorated(true);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == depositButton) {
            handleDeposit();
        } else if (ae.getSource() == exitButton) {
            setVisible(false);
            new Transaction().setVisible(true);
        }
    }

    private void handleDeposit() {
        String input = amountField.getText();

        // Validate the input
        if (input.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter the amount you want to deposit.");
            return;
        }

        try {
            double depositAmount = Double.parseDouble(input);

            // Ensure deposit amount is positive
            if (depositAmount <= 0) {
                JOptionPane.showMessageDialog(null, "Deposit amount must be greater than zero.");
                return;
            }

            // Record the transaction
            boolean success = transactionHandler.recordDeposit(depositAmount);

            if (success) {
                JOptionPane.showMessageDialog(null, "Deposited Successfully!");
                setVisible(false);
                new Transaction().setVisible(true);
            } else {
                JOptionPane.showMessageDialog(null, "Failed to record deposit. Please try again.");
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Please enter a valid deposit amount.");
        }
    }

    public static void main(String[] args) {
        new Deposit();
    }
}