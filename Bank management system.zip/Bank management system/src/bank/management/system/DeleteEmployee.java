package bank.management.system;
import bank.management.system.classes.EmployeeEntityClass;
import bank.management.system.classes.EmployeeManager;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;

// DeleteEmployee GUI class
public class DeleteEmployee extends JFrame implements ActionListener {
    JComboBox<String> comboEmpID;
    JLabel lblNameValue, lblPhoneValue, lblEmailValue;
    JButton btnDelete, btnBack;

    EmployeeManager employeeManager;

    DeleteEmployee() {
        employeeManager = new EmployeeManager(); // Initialize EmployeeManager

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // Background image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/1.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1100, 700, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 1100, 700);
        add(image);

        // Heading
        JLabel headings = new JLabel("DELETE EMPLOYEE ID");
        headings.setBounds(350, 07, 1000, 80);
        headings.setFont(new Font("serif", Font.BOLD, 35));
        headings.setForeground(Color.BLACK);
        image.add(headings);

        // Employee ID Label
        JLabel lblEmpID = new JLabel("Employee ID");
        lblEmpID.setBounds(100, 120, 150, 30);
        lblEmpID.setForeground(Color.BLACK);
        lblEmpID.setFont(new Font("SERIF", Font.BOLD, 25));
        image.add(lblEmpID);

        // Combo Box of Employee IDs
        comboEmpID = new JComboBox<>();
        comboEmpID.setBounds(270, 120, 250, 35);
        comboEmpID.addActionListener(this); // Add listener to detect selection changes
        image.add(comboEmpID);

        JLabel lblName = new JLabel("Name");
        lblName.setBounds(100, 180, 150, 30);
        lblName.setForeground(Color.BLACK);
        lblName.setFont(new Font("SERIF", Font.BOLD, 25));
        image.add(lblName);

        lblNameValue = new JLabel("-");
        lblNameValue.setBounds(270, 180, 300, 30);
        lblNameValue.setForeground(Color.BLACK);
        lblNameValue.setFont(new Font("SERIF", Font.BOLD, 25));
        image.add(lblNameValue);

        JLabel lblPhone = new JLabel("Phone");
        lblPhone.setBounds(100, 240, 210, 30);
        lblPhone.setForeground(Color.BLACK);
        lblPhone.setFont(new Font("SERIF", Font.BOLD, 25));
        image.add(lblPhone);

        lblPhoneValue = new JLabel("-");
        lblPhoneValue.setForeground(Color.BLACK);
        lblPhoneValue.setFont(new Font("SERIF", Font.BOLD, 25));
        lblPhoneValue.setBounds(270, 240, 300, 30);
        image.add(lblPhoneValue);

        JLabel lblEmail = new JLabel("Email:");
        lblEmail.setBounds(100, 300, 280, 30);
        lblEmail.setForeground(Color.BLACK);
        lblEmail.setFont(new Font("SERIF", Font.BOLD, 25));
        image.add(lblEmail);

        lblEmailValue = new JLabel("-");
        lblEmailValue.setBounds(270, 300, 300, 30);
        lblEmailValue.setFont(new Font("SERIF", Font.BOLD, 25));
        lblEmailValue.setForeground(Color.BLACK);
        image.add(lblEmailValue);

        btnDelete = new JButton("Delete");
        btnDelete.setBounds(350, 420, 120, 40);
        btnDelete.setFont(new Font("SERIF", Font.BOLD, 25));
        btnDelete.addActionListener(this);
        image.add(btnDelete);

        btnBack = new JButton("Back");
        btnBack.setBounds(550, 420, 120, 40);
        btnBack.setFont(new Font("SERIF", Font.BOLD, 25));
        btnBack.addActionListener(this);
        image.add(btnBack);

        // Load employee IDs into combo box
        loadEmployeeIDs();

        setSize(1100, 635);
        setLocation(140, 70);
        setVisible(true);
    }

    private void loadEmployeeIDs() {
        for (EmployeeEntityClass emp : employeeManager.getEmployees()) {
            comboEmpID.addItem(emp.getEmpID());
        }
    }

    private void updateEmployeeDetails(String empID) {
        EmployeeEntityClass emp = employeeManager.findEmployeeByID(empID);
        if (emp != null) {
            lblNameValue.setText(emp.getName());
            lblPhoneValue.setText(emp.getPhone());
            lblEmailValue.setText(emp.getEmail());
        } else {
            lblNameValue.setText("-");
            lblPhoneValue.setText("-");
            lblEmailValue.setText("-");
        }
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == comboEmpID) {
            String selectedEmpID = (String) comboEmpID.getSelectedItem();
            if (selectedEmpID != null) {
                updateEmployeeDetails(selectedEmpID);
            }
        } else if (ae.getSource() == btnDelete) {
            String selectedEmpID = (String) comboEmpID.getSelectedItem();
            if (selectedEmpID != null) {
                int confirmation = JOptionPane.showConfirmDialog(this,
                        "Are you sure you want to delete your account?",
                        "Confirm Delete",
                        JOptionPane.YES_NO_OPTION);

                if (confirmation == JOptionPane.YES_OPTION) {
                    boolean deleted = employeeManager.deleteEmployee(selectedEmpID);
                    if (deleted) {
                        JOptionPane.showMessageDialog(this, "Your account has been deleted successfully.");
                        setVisible(false);
                    } else {
                        JOptionPane.showMessageDialog(this, "Error deleting the account. Please try again.");
                    }
                }
            }
        } else if (ae.getSource() == btnBack) {
            setVisible(false);
            new employeepage();
        }
    }

    public static void main(String[] args) {
        new DeleteEmployee();
    }
}