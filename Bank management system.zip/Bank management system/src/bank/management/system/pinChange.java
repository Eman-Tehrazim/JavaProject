package bank.management.system;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class pinChange extends JFrame implements ActionListener{
    JTextField pin, repin;
    JButton exit, change;
    pinChange(){
        super("Banking Management System");

        // Image setup for background
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/g.jpg"));
        Image i2 = i1.getImage().getScaledInstance(720, 620, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 720, 620);
        add(image);
        
        JLabel text = new JLabel("CHANGE YOUR PIN");
        text.setFont(new Font("CASTELLAR", Font.BOLD, 18));
        text.setBounds(130, 115, 750, 50);
        text.setForeground(Color.BLACK);
        image.add(text);
        
        JLabel pintext = new JLabel("NEW PIN:");
        pintext.setFont(new Font("RALEWAY", Font.BOLD, 12));
        pintext.setBounds(170, 220, 500, 50);
        pintext.setForeground(Color.BLACK);
        image.add(pintext);
        
        pin = new JTextField();
        pin.setBounds(185, 260, 230, 25);
        pin.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(pin);
        
        JLabel rePin = new JLabel("RE-ENTER THE NEW PIN:");
        rePin.setFont(new Font("RALEWAY", Font.BOLD, 12));
        rePin.setBounds(170, 280, 500, 50);
        rePin.setForeground(Color.BLACK);
        image.add(rePin);
        
        repin = new JTextField();
        repin.setBounds(185, 320, 230, 25);
        repin.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(repin);
        
        change = new JButton("CHANGE");
        change.setBounds(250, 350, 90, 30);
        change.addActionListener(this);
        image.add(change);
        
        exit = new JButton("EXIT");
        exit.setBounds(500, 530, 100, 30);
        exit.addActionListener(this);
        image.add(exit);
        
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);    
        setSize(720, 620);
        setLocation(300, 100);
        setUndecorated(true);
        setVisible(true);   
    }  
    public void actionPerformed(ActionEvent ae){
        if(ae.getSource()== change){
            try{
                String npin = pin.getText();
                String rpin = repin.getText();
                if(!npin.equals(rpin)){
                    JOptionPane.showMessageDialog(null, "Entered pin doesnot match");
                    return;
                }
                if(npin.equals("")){
                    JOptionPane.showMessageDialog(null, "Please enter the pin");
                    return;
                }
                if(rpin.equals("")){
                    JOptionPane.showMessageDialog(null, "Please enter the re enter new pin");
                    return;
                }
                if(!pin.equals(npin)){
                    // Old pin matches, update with new pin
                    String pinno = npin;
                JOptionPane.showMessageDialog(null, "Pin changed successfully!");
                setVisible(false);
                new Transaction().setVisible(true); 
            } else {
                JOptionPane.showMessageDialog(null, "New pin cannot be same as old pin");
            }
            setVisible(false);
            new Transaction().setVisible(true);
            } catch (Exception e){
                System.out.println(e);
            }
        }
        else{
            setVisible(false);
            new Transaction().setVisible(true);
        }
    }
        public static void main(String[]args){
           new pinChange().setVisible(true);
    }
}
