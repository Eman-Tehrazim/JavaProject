package bank.management.system;
import bank.management.system.classes.BankAccountClass;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import java.awt.event.*;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Withdraw extends JFrame implements ActionListener {
    JTextField amount;
    JButton exit, withdraw;

  
    Withdraw() {
        super("Banking Management System");

    
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/g.jpg"));
        Image i2 = i1.getImage().getScaledInstance(720, 620, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 720, 620);
        add(image);

 
        JLabel text = new JLabel("ENTER THE AMOUNT YOU WANT TO WITHDRAW");
        text.setFont(new Font("CASTELLAR", Font.PLAIN, 13));
        text.setBounds(127, 125, 750, 50);
        text.setForeground(Color.BLACK);
        image.add(text);

      
        amount = new JTextField();
        amount.setBounds(195, 270, 220, 25);
        amount.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(amount);

 
        withdraw = new JButton("WITHDRAW");
        withdraw.setBounds(315, 325, 100, 35);
        withdraw.addActionListener(this);
        image.add(withdraw);

        exit = new JButton("EXIT");
        exit.setBounds(195, 325, 80, 35);
        exit.addActionListener(this);
        image.add(exit);

     
        setLayout(null);
        getContentPane().setBackground(Color.WHITE);    
        setSize(720, 620);
        setLocation(300, 100);
        setUndecorated(true);
        setVisible(true);     
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == withdraw) {
            String number = amount.getText();
            try {
                double bl = BankAccountClass.calculateBalance();
                if(Double.parseDouble(number) >= bl){
                JOptionPane.showMessageDialog(null, "Withdraw must be successful.");  
                    return;  
                }
                    } catch (IOException ex) {
                Logger.getLogger(Withdraw.class.getName()).log(Level.SEVERE, null, ex);
            }
            // Check if the amount field is not empty
            if (number.equals("")) {
                JOptionPane.showMessageDialog(null, "Please enter the amount you want to withdraw.");
            } else {
                try {
                    // Get the current date and time for the transaction
                    Date date = new Date();

                    // Store the withdrawal amount and date into the file
                    File file = new File("Deposit.txt");

                    // Create the file if it doesn't exist
                    if (!file.exists()) {
                        file.createNewFile();
                    }

                    // Open the file in append mode to add a new withdrawal record
                    FileWriter writer = new FileWriter(file, true);
                    String transaction = "Amount Withdrawn: " + number + ", Date: " + date.toString() + "\n";
                    writer.write(transaction);
                    writer.close();

                    // Show success message
                    JOptionPane.showMessageDialog(null, "Withdrawal of " + number + " was successful!");
                    setVisible(false);
                    new Transaction().setVisible(true); 
                } catch (IOException e) {
                    JOptionPane.showMessageDialog(null, "Error writing to file: " + e.getMessage());
                }
            }
        } else if (ae.getSource() == exit) {
            setVisible(false);
            new Transaction().setVisible(true); // Go back to the Transaction screen (or any other screen)
        }
    }

    public static void main(String[] args) {
        new Withdraw(); // Start Withdraw screen
    }
}