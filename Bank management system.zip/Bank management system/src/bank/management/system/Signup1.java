package bank.management.system;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.io.BufferedWriter; // to write data in the file
import java.io.FileWriter;
import java.io.IOException; // file not found y errors ko deal krti hai
import java.util.Random; // to generate random number
import javax.swing.*;
import java.awt.event.*; // to handle all the events
import com.toedter.calendar.JDateChooser; // calender import

public class Signup1 extends JFrame implements ActionListener {

    long random;
    JTextField nameTextField, fnameTextField, emailTextField, addressTextField, cityTextField, stateTextField, pinTextField;
    JButton next;
    JRadioButton male, female, married, unmarried, other;
    JDateChooser datechooser;

    // Constructor
    Signup1() {
        super("Banking Management System");

        // Image setup for background
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/y.jpg"));
        Image i2 = i1.getImage().getScaledInstance(700, 570, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(1, 1, 700, 570);
        add(image);

        // Generate a random form number
        Random ran = new Random();
        random = Math.abs((ran.nextLong() % 9000L) + 1000L);
        JLabel text = new JLabel("APPLICATION FORM NO: " + random);
        text.setFont(new Font("CASTELLAR", Font.BOLD, 30));
        text.setBounds(75, 20, 750, 50);
        text.setForeground(Color.DARK_GRAY);
        image.add(text);

        // Adding labels and text fields
        JLabel persdeta = new JLabel("Personal Details");
        persdeta.setFont(new Font("RALEWAY", Font.BOLD, 20));
        persdeta.setBounds(255, 55, 750, 50);
        persdeta.setForeground(Color.DARK_GRAY);
        image.add(persdeta);

        JLabel name = new JLabel("Name: ");
        name.setFont(new Font("RALEWAY", Font.BOLD, 15));
        name.setBounds(60, 110, 570, 30);
        name.setForeground(Color.DARK_GRAY);
        image.add(name);
        
        nameTextField = new JTextField();
        nameTextField.setBounds(200, 115, 310, 25);
        nameTextField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(nameTextField);

        JLabel fname = new JLabel("Father's Name: ");
        fname.setFont(new Font("RALEWAY", Font.BOLD, 15));
        fname.setBounds(60, 150, 570, 30);
        fname.setForeground(Color.DARK_GRAY);
        image.add(fname);
        
        fnameTextField = new JTextField();
        fnameTextField.setBounds(200, 155, 310, 25);
        fnameTextField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(fnameTextField);

        JLabel dob = new JLabel("Date of Birth: ");
        dob.setFont(new Font("RALEWAY", Font.BOLD, 15));
        dob.setBounds(60, 190, 570, 30);
        dob.setForeground(Color.DARK_GRAY);
        image.add(dob);
        
        datechooser = new JDateChooser();
        datechooser.setBounds(200, 195, 250, 25);
        datechooser.setForeground(new Color(105, 105, 105));
        image.add(datechooser);

        JLabel gender = new JLabel("Gender: ");
        gender.setFont(new Font("RALEWAY", Font.BOLD, 15));
        gender.setBounds(60, 230, 570, 30);
        gender.setForeground(Color.DARK_GRAY);
        image.add(gender);
        
        male = new JRadioButton("Male");
        male.setBounds(200, 235, 100, 25);
        image.add(male);
        
        female = new JRadioButton("Female");
        female.setBounds(350, 235, 100, 25);
        image.add(female);
        
        ButtonGroup gendergroup = new ButtonGroup();
        gendergroup.add(male);
        gendergroup.add(female);

        JLabel email = new JLabel("Email Address: ");
        email.setFont(new Font("RALEWAY", Font.BOLD, 15));
        email.setBounds(60, 270, 570, 30);
        email.setForeground(Color.DARK_GRAY);
        image.add(email);
        
        emailTextField = new JTextField();
        emailTextField.setBounds(200, 275, 310, 25);
        emailTextField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(emailTextField);

        JLabel marital = new JLabel("Marital Status: ");
        marital.setFont(new Font("RALEWAY", Font.BOLD, 15));
        marital.setBounds(60, 310, 570, 30);
        marital.setForeground(Color.DARK_GRAY);
        image.add(marital);
        
        married = new JRadioButton("Married");
        married.setBounds(200, 315, 100, 25);
        image.add(married);
        
        unmarried = new JRadioButton("Unmarried");
        unmarried.setBounds(350, 315, 100, 25);
        image.add(unmarried);
        
        other = new JRadioButton("Other");
        other.setBounds(500, 315, 100, 25);
        image.add(other);
        
        ButtonGroup maritalgroup = new ButtonGroup();
        maritalgroup.add(married);
        maritalgroup.add(unmarried);
        maritalgroup.add(other);

        JLabel address = new JLabel("Address: ");
        address.setFont(new Font("RALEWAY", Font.BOLD, 15));
        address.setBounds(60, 350, 570, 30);
        address.setForeground(Color.DARK_GRAY);
        image.add(address);
        
        addressTextField = new JTextField();
        addressTextField.setBounds(200, 355, 310, 25);
        addressTextField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(addressTextField);

        JLabel city = new JLabel("City: ");
        city.setFont(new Font("RALEWAY", Font.BOLD, 15));
        city.setBounds(60, 390, 570, 30);
        city.setForeground(Color.WHITE);
        image.add(city);
        
        cityTextField = new JTextField();
        cityTextField.setBounds(200, 395, 310, 25);
        cityTextField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(cityTextField);

        JLabel state = new JLabel("State: ");
        state.setFont(new Font("RALEWAY", Font.BOLD, 15));
        state.setBounds(60, 430, 570, 30);
        state.setForeground(Color.WHITE);
        image.add(state);
        
        stateTextField = new JTextField();
        stateTextField.setBounds(200, 435, 310, 25);
        stateTextField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(stateTextField);

        JLabel pincode = new JLabel("Pin Code: ");
        pincode.setFont(new Font("RALEWAY", Font.BOLD, 15));
        pincode.setBounds(60, 470, 570, 30);
        pincode.setForeground(Color.WHITE);
        image.add(pincode);
        
        pinTextField = new JTextField();
        pinTextField.setBounds(200, 475, 310, 25);
        pinTextField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(pinTextField);

        next = new JButton("NEXT");
        next.setBounds(500, 530, 100, 30);
        next.addActionListener(this);
        image.add(next);

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setSize(720, 620);
        setLocation(300, 100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        String name = nameTextField.getText();
        String fname = fnameTextField.getText();
        String dob = ((JTextField) datechooser.getDateEditor().getUiComponent()).getText();
        String gender = null;
        
        if (male.isSelected()) {
            gender = "Male";
        } 
        else if (female.isSelected()) {
            gender = "Female";
        }

        String email = emailTextField.getText();
        
        String marital = null; 
        
        if (married.isSelected()) {
            marital = "Married";
        } 
        else if (unmarried.isSelected()) {
            marital = "Unmarried";
        } 
        else if (other.isSelected()) {
            marital = "Other";
        }

        String address = addressTextField.getText();
        String city = cityTextField.getText();
        String state = stateTextField.getText();
        String pin = pinTextField.getText();

        // Validation
        if (name.isEmpty() || fname.isEmpty() || email.isEmpty() || address.isEmpty() || city.isEmpty() || state.isEmpty() || pin.isEmpty()) {
            JOptionPane.showMessageDialog(null, "All fields are required.");
            return;
        }

        // Validate Name and Father's Name (Alphabetic only)
        if (!name.matches("[A-Za-z]+") || !fname.matches("[A-Za-z]+") || !city.matches("[A-Za-z]+") || !state.matches("[A-Za-z]+")) {
            JOptionPane.showMessageDialog(null, "name, fname, city, state can only contain alphabetic characters.");
            return;
        }

        // Validate Email format using a regular expression
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        if (!email.matches(emailRegex)) {
            JOptionPane.showMessageDialog(null, "Invalid email format.");
            return;
        }

        // Validate Pin Code (6 digits)
        if (!pin.matches("\\d{6}")) {
            JOptionPane.showMessageDialog(null, "Pin Code must be exactly 6 digits.");
            return;
        }

        // Validate Address (Allow alphanumeric)
        if (!address.matches("[A-Za-z0-9\\s]+")) {
            JOptionPane.showMessageDialog(null, "Address can contain letters, numbers, and spaces only.");
            return;
        }

        // Validate Date of Birth is not empty
        if (dob.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Date of Birth is required.");
            return;
        }

        setVisible(false);
        new Signup2().setVisible(true);

        // Save information to file
        saveInfo(name, fname, dob, gender, email, marital, address, city, state, pin);
    }

    // Method to save user info to a file
    public void saveInfo(String name, String fname, String dob, String gender, String email, String marital, String address, String city, String state, String pin) {
        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter("Signup.txt", true));
            bw.write("Form No: " + random);
            bw.newLine();
            bw.write("Name: " + name);
            bw.newLine();
            bw.write("Father's Name: " + fname);
            bw.newLine();
            bw.write("Date of Birth: " + dob);
            bw.newLine();
            bw.write("Gender: " + gender);
            bw.newLine();
            bw.write("Email: " + email);
            bw.newLine();
            bw.write("Marital Status: " + marital);
            bw.newLine();
            bw.write("Address: " + address);
            bw.newLine();
            bw.write("City: " + city);
            bw.newLine();
            bw.write("State: " + state);
            bw.newLine();
            bw.write("Pin Code: " + pin);
            bw.newLine();
            bw.newLine();
            bw.close();
        } catch (IOException e) {
            e.printStackTrace(); // exception error jo ata hai usko trace krny ky bad print kr daita console py
        }
    }

    public static void main(String[] args) {
        new Signup1();
    }

    // Getter and Setter methods

    public JTextField getNameTextField() {
        return nameTextField;
    }

    public void setNameTextField(JTextField nameTextField) {
        this.nameTextField = nameTextField;
    }

    public JTextField getFnameTextField() {
        return fnameTextField;
    }

    public void setFnameTextField(JTextField fnameTextField) {
        this.fnameTextField = fnameTextField;
    }

    public JTextField getEmailTextField() {
        return emailTextField;
    }

    public void setEmailTextField(JTextField emailTextField) {
        this.emailTextField = emailTextField;
    }

    public JTextField getAddressTextField() {
        return addressTextField;
    }

    public void setAddressTextField(JTextField addressTextField) {
        this.addressTextField = addressTextField;
    }

    public JTextField getCityTextField() {
        return cityTextField;
    }

    public void setCityTextField(JTextField cityTextField) {
        this.cityTextField = cityTextField;
    }

    public JTextField getStateTextField() {
        return stateTextField;
    }

    public void setStateTextField(JTextField stateTextField) {
        this.stateTextField = stateTextField;
    }

    public JTextField getPinTextField() {
        return pinTextField;
    }

    public void setPinTextField(JTextField pinTextField) {
        this.pinTextField = pinTextField;
    }

    public JRadioButton getMale() {
        return male;
    }

    public void setMale(JRadioButton male) {
        this.male = male;
    }

    public JRadioButton getFemale() {
        return female;
    }

    public void setFemale(JRadioButton female) {
        this.female = female;
    }

    public JRadioButton getMarried() {
        return married;
    }

    public void setMarried(JRadioButton married) {
        this.married = married;
    }

    public JRadioButton getUnmarried() {
        return unmarried;
    }

    public void setUnmarried(JRadioButton unmarried) {
        this.unmarried = unmarried;
    }

    public JRadioButton getOther() {
        return other;
    }

    public void setOther(JRadioButton other) {
        this.other = other;
    }

    public JDateChooser getDatechooser() {
        return datechooser;
    }

    public void setDatechooser(JDateChooser datechooser) {
        this.datechooser = datechooser;
    }

    public JButton getNext() {
        return next;
    }

    public void setNext(JButton next) {
        this.next = next;
    }
}
