package bank.management.system;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import javax.swing.*;
import java.awt.event.*;

public class Signup2 extends JFrame implements ActionListener {

    private final JTextField PANTextField;
    private final JTextField IDCARDTextField;
    private JButton next;
    private JButton back;
    private JRadioButton scyes;
    private JRadioButton scno, eayes, eano;
    private JComboBox<String> religion;
    private JComboBox<String> category, income, Edu, qual, occup;

    public Signup2() {
        super("Banking Management System");

        // Image setup for background
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/bank.jpg"));
        Image i2 = i1.getImage().getScaledInstance(700, 570, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(1, 1, 700, 570);
        add(image);

        JLabel text = new JLabel("ADDITIONAL DETAILS");
        text.setFont(new Font("CASTELLAR", Font.BOLD, 30));
        text.setBounds(150, 20, 750, 50);
        text.setForeground(Color.WHITE);
        image.add(text);

        // Adding fields and labels for religion, category, income, etc.
        JLabel rel = new JLabel("Religion: ");
        rel.setFont(new Font("RALEWAY", Font.BOLD, 15));
        rel.setBounds(60, 110, 570, 30);
        rel.setForeground(Color.WHITE);
        image.add(rel);
        
        String[] valReligion = {"Hindus", "Muslims", "Christians", "Sikhs", "Others"};
        religion = new JComboBox(valReligion);
        religion.setBounds(200, 115, 310, 25);
        religion.setBackground(Color.WHITE);
        image.add(religion);

        JLabel cate = new JLabel("Category: ");
        cate.setFont(new Font("RALEWAY", Font.BOLD, 15));
        cate.setBounds(60, 150, 570, 30);
        cate.setForeground(Color.WHITE);
        image.add(cate);
        
        String[] valCategory = {"ELLITES", "UMC", "LMC", "MC", "Others"};
        category = new JComboBox(valCategory);
        category.setBounds(200, 155, 310, 25);
        category.setBackground(Color.WHITE);
        image.add(category);

        JLabel inc = new JLabel("Income: ");
        inc.setFont(new Font("RALEWAY", Font.BOLD, 15));
        inc.setBounds(60, 190, 570, 30);
        inc.setForeground(Color.WHITE);
        image.add(inc);
        
        String[] valincome = {"NULL", "10,0000", "150,000", "20,0000", "500,0000", "Upto 100,00000"};
        income = new JComboBox(valincome);
        income.setBounds(200, 195, 310, 25);
        income.setBackground(Color.WHITE);
        image.add(income);

        JLabel education = new JLabel("Educational: ");
        education.setFont(new Font("RALEWAY", Font.BOLD, 15));
        education.setBounds(60, 230, 570, 30);
        education.setForeground(Color.WHITE);
        image.add(education);
        
        String[] valEdu = {"PE", "LSE", "USE", "PSE", "Others"};
        Edu = new JComboBox(valEdu);
        Edu.setBounds(200, 235, 310, 25);
        Edu.setBackground(Color.WHITE);
        image.add(Edu);

        JLabel qualification = new JLabel("Qualification: ");
        qualification.setFont(new Font("RALEWAY", Font.BOLD, 15));
        qualification.setBounds(60, 270, 570, 30);
        qualification.setForeground(Color.WHITE);
        image.add(qualification);
        
        String[] valqual = {"UGRAD", "GRADS", "MASTERS", "DOCTORAL", "Others"};
        qual = new JComboBox(valqual);
        qual.setBounds(200, 275, 310, 25);
        qual.setBackground(Color.WHITE);
        image.add(qual);

        JLabel occupation = new JLabel("Occupation: ");
        occupation.setFont(new Font("RALEWAY", Font.BOLD, 15));
        occupation.setBounds(60, 310, 570, 30);
        occupation.setForeground(Color.WHITE);
        image.add(occupation);
        
        String[] valocup = {"Businessmen", "Salaried", "Self-Employed", "Retired", "Student", "Others"};
        occup = new JComboBox(valocup);
        occup.setBounds(200, 315, 310, 25);
        occup.setBackground(Color.WHITE);
        image.add(occup);

        JLabel pan = new JLabel("PAN Number: ");// permanent account number
        pan.setFont(new Font("RALEWAY", Font.BOLD, 15));
        pan.setBounds(60, 350, 570, 30);
        pan.setForeground(Color.WHITE);
        image.add(pan);
        
        PANTextField = new JTextField();
        PANTextField.setBounds(200, 355, 310, 25);
        PANTextField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(PANTextField);

        JLabel id = new JLabel("ID Card Number: ");
        id.setFont(new Font("RALEWAY", Font.BOLD, 15));
        id.setBounds(60, 390, 570, 30);
        id.setForeground(Color.WHITE);
        image.add(id);
        
        IDCARDTextField = new JTextField();
        IDCARDTextField.setBounds(200, 395, 310, 25);
        IDCARDTextField.setFont(new Font("Ariel", Font.PLAIN, 14));
        image.add(IDCARDTextField);

        JLabel seniorcitizen = new JLabel("Senior Citizen: ");
        seniorcitizen.setFont(new Font("RALEWAY", Font.BOLD, 15));
        seniorcitizen.setBounds(60, 430, 570, 30);
        seniorcitizen.setForeground(Color.WHITE);
        image.add(seniorcitizen);
        
        scyes = new JRadioButton("YES");
        scyes.setBounds(200, 435, 100, 25);
        image.add(scyes);
        
        scno = new JRadioButton("NO");
        scno.setBounds(350, 435, 100, 25);
        image.add(scno);
        
        ButtonGroup scgroup = new ButtonGroup();
        scgroup.add(scyes);
        scgroup.add(scno);

        JLabel existingAccount = new JLabel("Existing Account: ");
        existingAccount.setFont(new Font("RALEWAY", Font.BOLD, 15));
        existingAccount.setBounds(60, 470, 570, 30);
        existingAccount.setForeground(Color.WHITE);
        image.add(existingAccount);
        
        eayes = new JRadioButton("YES");
        eayes.setBounds(200, 475, 100, 25);
        image.add(eayes);
        
        eano = new JRadioButton("NO");
        eano.setBounds(350, 475, 100, 25);
        image.add(eano);
        
        ButtonGroup eagrp = new ButtonGroup();
        eagrp.add(eayes);
        eagrp.add(eano);

        next = new JButton("NEXT");
        next.setBounds(500, 530, 100, 30);
        next.addActionListener(this);
        image.add(next);

        back = new JButton("BACK");
        back.setBounds(100, 530, 100, 30);
        back.addActionListener(this);
        image.add(back);

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setSize(720, 620);
        setLocation(300, 100);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == next) {
            String religionVal = (String) religion.getSelectedItem();
            String categoryVal = (String) category.getSelectedItem();
            String incomeVal = (String) income.getSelectedItem();
            String eduVal = (String) Edu.getSelectedItem();
            String qualVal = (String) qual.getSelectedItem();
            String occupVal = (String) occup.getSelectedItem();
            String pan = PANTextField.getText();
            String idCard = IDCARDTextField.getText();
            String seniorcitizen = null;
            if (scyes.isSelected()) {
                seniorcitizen = "YES";
            } 
            else if (scno.isSelected()) {
                seniorcitizen = "NO";
            }

            String existingaccount = null;
            if (eayes.isSelected()) {
                existingaccount = "YES";
            } 
            else if (eano.isSelected()) {
                existingaccount = "NO";
            }

            // Validate the fields
            if (pan.equals("") || idCard.equals("") || religionVal == null || categoryVal == null || incomeVal == null || eduVal == null || qualVal == null || occupVal == null || seniorcitizen == null || existingaccount == null) {
                JOptionPane.showMessageDialog(null, "All fields are required.");
                return;
            }

            // PAN Number validation (format: AAAAA1234A)
            String panRegex = "[A-Za-z]{5}[0-9]{4}[A-Za-z]{1}";
            if (!pan.matches(panRegex)) {
                JOptionPane.showMessageDialog(null, "Invalid PAN Number. It should be in the format AAAAA1234A.");
                return;
            }

            // ID Card Number validation (alphanumeric and length check, assuming 12 characters)
            if (idCard.length() != 13 || !idCard.matches("[0-9]{13}")) {
                JOptionPane.showMessageDialog(null, "Invalid ID Card Number. It should be 13 numeric characters.");
                return;
            }
            setVisible(false);
            new Signup3().setVisible(true); // Assuming Signup3 is implemented

            // Save the information to a file // declaration
            saveInfo(religionVal, categoryVal, incomeVal, eduVal, qualVal, occupVal, pan, idCard, seniorcitizen, existingaccount);
        } else if (ae.getSource() == back) {
            // Go back to the previous screen (Signup1)
            new Signup1();  // Assuming you have a Signup1 class to navigate back
            setVisible(false);  // Close the current screen
        }
    }

    public void saveInfo(String religion, String category, String income, String edu, String qual, String occup, String pan, String idCard, String seniorCitizen, String existingAccount) {
        try {
            BufferedWriter writer = new BufferedWriter(new FileWriter("signup2.txt"));
            writer.write("Religion: " + religion);
            writer.newLine();
            writer.write("Category: " + category);
            writer.newLine();
            writer.write("Income: " + income);
            writer.newLine();
            writer.write("Education: " + edu);
            writer.newLine();
            writer.write("Qualification: " + qual);
            writer.newLine();
            writer.write("Occupation: " + occup);
            writer.newLine();
            writer.write("PAN Number: " + pan);
            writer.newLine();
            writer.write("ID Card Number: " + idCard);
            writer.newLine();
            writer.write("Senior Citizen: " + seniorCitizen);
            writer.newLine();
            writer.write("Existing Account: " + existingAccount);
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // Getter and Setter Methods for all fields
    public String getReligion() {
        return (String) religion.getSelectedItem();
    }

    public void setReligion(String religion) {
        this.religion.setSelectedItem(religion);
    }

    public String getCategory() {
        return (String) category.getSelectedItem();
    }

    public void setCategory(String category) {
        this.category.setSelectedItem(category);
    }

    public String getIncome() {
        return (String) income.getSelectedItem();
    }

    public void setIncome(String income) {
        this.income.setSelectedItem(income);
    }

    public String getEdu() {
        return (String) Edu.getSelectedItem();
    }

    public void setEdu(String edu) {
        this.Edu.setSelectedItem(edu);
    }

    public String getQualification() {
        return (String) qual.getSelectedItem();
    }

    public void setQualification(String qualification) {
        this.qual.setSelectedItem(qualification);
    }

    public String getOccupation() {
        return (String) occup.getSelectedItem();
    }

    public void setOccupation(String occupation) {
        this.occup.setSelectedItem(occupation);
    }

    public String getPan() {
        return PANTextField.getText();
    }

    public void setPan(String pan) {
        this.PANTextField.setText(pan);
    }

    public String getIdCard() {
        return IDCARDTextField.getText();
    }

    public void setIdCard(String idCard) {
        this.IDCARDTextField.setText(idCard);
    }

    public boolean isSeniorCitizenYes() {
        return scyes.isSelected();
    }

    public void setSeniorCitizenYes(boolean selected) {
        this.scyes.setSelected(selected);
    }

    public boolean isExistingAccountYes() {
        return eayes.isSelected();
    }

    public void setExistingAccountYes(boolean selected) {
        this.eayes.setSelected(selected);
    }

    public static void main(String[] args) {
        new Signup2();
    }
}
