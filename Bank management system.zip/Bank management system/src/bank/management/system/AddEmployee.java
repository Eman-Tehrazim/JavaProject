package bank.management.system;
import bank.management.system.classes.EmployeeClass;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.toedter.calendar.JDateChooser;
import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;



public class AddEmployee extends JFrame implements ActionListener {

    Random ran = new Random();
    int number = ran.nextInt(999999);

    JTextField tfname, tffname, tfaddress, tfphone, tfcnic, tfemail, tfsalary, tfdesignation;
    JDateChooser dcdob;
    JComboBox<String> cbeducation;
    JLabel lblempid;
    JButton add, back;

    AddEmployee() {
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);

        // Add Employee1 Form UI
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icon/2.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1100, 635, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 1100, 635);
        add(image);

        JLabel heading = new JLabel("ADD EMPLOYEE DETAILS");
        heading.setBounds(260, 40, 700, 30);
        heading.setFont(new Font("serif", Font.BOLD, 40));
        image.add(heading);

        JLabel labelname = new JLabel("Name");
        labelname.setBounds(60, 150, 150, 40);
        labelname.setForeground(Color.BLACK);
        labelname.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labelname);

        tfname = new JTextField();
        tfname.setBounds(190, 160, 220, 30);
        image.add(tfname);

        JLabel labelfname = new JLabel("Father's Name");
        labelfname.setBounds(550, 150, 220, 40);
        labelfname.setForeground(Color.BLACK);
        labelfname.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labelfname);

        tffname = new JTextField();
        tffname.setBounds(720, 160, 220, 30);
        image.add(tffname);

        JLabel labeldob = new JLabel("Date Of Birth");
        labeldob.setBounds(60, 210, 220, 40);
        labeldob.setForeground(Color.BLACK);
        labeldob.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labeldob);

        dcdob = new JDateChooser();
        dcdob.setBounds(190, 215, 220, 30);
        image.add(dcdob);

        JLabel labelsalary = new JLabel("Salary");
        labelsalary.setBounds(550, 210, 220, 40);
        labelsalary.setForeground(Color.BLACK);
        labelsalary.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labelsalary);

        tfsalary = new JTextField();
        tfsalary.setBounds(720, 215, 220, 30);
        image.add(tfsalary);

        JLabel labeladdress = new JLabel("Address");
        labeladdress.setBounds(60, 270, 220, 30);
        labeladdress.setForeground(Color.BLACK);
        labeladdress.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labeladdress);

        tfaddress = new JTextField();
        tfaddress.setBounds(190, 270, 220, 30);
        image.add(tfaddress);

        JLabel labelphone = new JLabel("Phone");
        labelphone.setBounds(550, 270, 220, 40);
        labelphone.setForeground(Color.BLACK);
        labelphone.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labelphone);

        tfphone = new JTextField();
        tfphone.setBounds(720, 270, 220, 30);
        image.add(tfphone);

        JLabel labelemail = new JLabel("Email");
        labelemail.setBounds(60, 330, 220, 30);
        labelemail.setForeground(Color.BLACK);
        labelemail.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labelemail);

        tfemail = new JTextField();
        tfemail.setBounds(190, 325, 220, 30);
        image.add(tfemail);

        JLabel labeleducation = new JLabel("Highest Education");
        labeleducation.setBounds(550, 330, 220, 30);
        labeleducation.setForeground(Color.BLACK);
        labeleducation.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labeleducation);

        String courses[] = {"BSSE", "BCA", "B.COM", "BSSC", "BA", "BTech", "MBA", "MCA", "MA", "MSC", "PHD"};
        cbeducation = new JComboBox<>(courses);
        cbeducation.setBackground(Color.WHITE);
        cbeducation.setBounds(720, 325, 220, 30);
        image.add(cbeducation);

        JLabel labeldesignation = new JLabel("Designation");
        labeldesignation.setBounds(60, 385, 220, 30);
        labeldesignation.setForeground(Color.BLACK);
        labeldesignation.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labeldesignation);

        tfdesignation = new JTextField();
        tfdesignation.setBounds(190, 380, 220, 30);
        image.add(tfdesignation);

        JLabel labelcnic = new JLabel("CNIC Number");
        labelcnic.setBounds(550, 385, 220, 30);
        labelcnic.setForeground(Color.BLACK);
        labelcnic.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labelcnic);

        tfcnic = new JTextField();
        tfcnic.setBounds(720, 380, 220, 30);
        image.add(tfcnic);

        JLabel labelempid = new JLabel("Employee ID");
        labelempid.setBounds(60, 445, 220, 30);
        labelempid.setForeground(Color.BLACK);
        labelempid.setFont(new Font("SERIF", Font.BOLD, 20));
        image.add(labelempid);

        lblempid = new JLabel("" + number);
        lblempid.setBounds(190, 445, 220, 30);
        lblempid.setFont(new Font("SERIF", Font.BOLD, 25));
        lblempid.setForeground(Color.WHITE);
        image.add(lblempid);

        add = new JButton("Add Details");
        add.setBounds(360, 510, 150, 60);
        add.setFont(new Font("Serif", Font.BOLD, 20));
        add.addActionListener(this);
        image.add(add);

        back = new JButton("Back Details");
        back.setBounds(560, 510, 150, 60);
        back.setFont(new Font("Serif", Font.BOLD, 20));
        back.addActionListener(this);
        image.add(back);

        setSize(1100, 635);
        setLocation(150, 70);
        setVisible(true);
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == add) {
            String name = tfname.getText();
            String fname = tffname.getText();
            String dob = null;
            if (dcdob.getDate() != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                dob = sdf.format(dcdob.getDate());
            }
            String salary = tfsalary.getText();
            String address = tfaddress.getText();
            String phone = tfphone.getText();
            String email = tfemail.getText();
            String education = (String) cbeducation.getSelectedItem();
            String designation = tfdesignation.getText();
            String cnic = tfcnic.getText();
            String empid = lblempid.getText();

            if (name.isEmpty() || fname.isEmpty() || dob == null || salary.isEmpty() || address.isEmpty() || phone.isEmpty() || email.isEmpty() || education == null || designation.isEmpty() || cnic.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill out all the fields.");
                return;
            }

            try {
                Double.parseDouble(salary);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Please enter a valid salary.");
                return;
            }

            if (!phone.matches("\\d{11}")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid 11-digit phone number.");
                return;
            }

            String emailPattern = "^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
            if (!email.matches(emailPattern)) {
                JOptionPane.showMessageDialog(null, "Please enter a valid email address.");
                return;
            }

            if (!cnic.matches("\\d{5}-\\d{7}-\\d{1}")) {
                JOptionPane.showMessageDialog(null, "Please enter a valid CNIC number in the format xxxxx-xxxxxxx-x.");
                return;
            }

            EmployeeClass employee = new EmployeeClass(name, fname, dob, salary, address, phone, email, education, designation, cnic, empid);
            try {
                employee.saveToFile();
            } catch (IOException ex) {
                Logger.getLogger(AddEmployee.class.getName()).log(Level.SEVERE, null, ex);
            }
            JOptionPane.showMessageDialog(null, "Employee Details Added Successfully");
            setVisible(false);
            new employeepage();
        } else if (ae.getSource() == back) {
            setVisible(false);
            new employeepage();
        }
    }

    public static void main(String[] args) {
        new AddEmployee();
    }
}