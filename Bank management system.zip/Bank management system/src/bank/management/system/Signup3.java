package bank.management.system;

import bank.management.system.classes.IAccountType;
import bank.management.system.classes.ICardGeneration;
import bank.management.system.classes.IServicesRequired;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import java.awt.event.*;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class Signup3 extends JFrame implements ActionListener, IAccountType, IServicesRequired, ICardGeneration {
    long random;
    JCheckBox c1, c2, c3, c4;
    JButton submit, cancel, create;
    JRadioButton r1, r2, r3, r4;

    Signup3() {
        super("Banking Management System");
        
        // Image setup for background
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/u.jpg"));
        Image i2 = i1.getImage().getScaledInstance(700, 570, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(1, 1, 700, 570);
        add(image);

        JLabel text = new JLabel("ACCOUNT DETAILS");
        text.setFont(new Font("CASTELLAR", Font.BOLD, 30));
        text.setBounds(160, 20, 750, 50);
        text.setForeground(Color.DARK_GRAY);
        image.add(text);

        // Adding fields and labels for religion, category, income, etc.
        JLabel acType = new JLabel("ACCOUNT TYPE");
        acType.setFont(new Font("CASTELLAR", Font.BOLD, 16));
        acType.setBounds(80, 90, 570, 30);
        acType.setForeground(Color.DARK_GRAY);
        image.add(acType);
        
        r1 = new JRadioButton("SAVING ACCOUNT");
        r1.setBounds(135, 135, 150, 25);
        image.add(r1);
        
        r2 = new JRadioButton("FIXED DEPOSIT ACCOUNT");
        r2.setBounds(380, 135, 200, 28);
        image.add(r2);
        
        r3 = new JRadioButton("CURRENT ACCOUNT");
        r3.setBounds(135, 175, 150, 25);
        image.add(r3);
        
        r4 = new JRadioButton("RECURRING DEPOSIT ACCOUNT");
        r4.setBounds(380, 175, 206, 28);
        image.add(r4);
        
        ButtonGroup acgroup = new ButtonGroup();
        acgroup.add(r1);
        acgroup.add(r2);
        acgroup.add(r3);
        acgroup.add(r4);
        
        create = new JButton("CREATE");
        create.setBounds(280, 220, 100, 30);
        create.addActionListener(this);
        image.add(create);
        
        Random ran = new Random();
        random =  Math.abs((ran.nextLong() % 900000000L) + 5039475900000000L);
        JLabel cardno = new JLabel("CARD NUMBER: ");
        cardno.setFont(new Font("RALEWAY", Font.BOLD, 15));
        cardno.setBounds(135, 265, 570, 30);
        cardno.setForeground(Color.DARK_GRAY);
        image.add(cardno);
       
        JLabel number = new JLabel("$$$$-$$$$-$$$$-$$$$");
        number.setFont(new Font("RALEWAY", Font.BOLD, 15));
        number.setBounds(280, 265, 570, 30);
        number.setForeground(Color.DARK_GRAY);
        image.add(number);
        
        JLabel no = new JLabel("This is your 16-digits card number");
        no.setFont(new Font("RALEWAY", Font.BOLD, 13));
        no.setBounds(280, 285, 570, 30);
        no.setForeground(Color.WHITE);
        image.add(no);
        
        
        random =  Math.abs((ran.nextLong() % 9000L) + 1000L);
        JLabel pin = new JLabel("PIN: ");
        pin.setFont(new Font("RALEWAY", Font.BOLD, 15));
        pin.setBounds(135, 320, 570, 30);
        pin.setForeground(Color.DARK_GRAY);
        image.add(pin);
       
        JLabel pnumber = new JLabel("$$$$");
        pnumber.setFont(new Font("RALEWAY", Font.BOLD, 15));
        pnumber.setBounds(280, 320, 570, 30);
        pnumber.setForeground(Color.DARK_GRAY);
        image.add(pnumber);
        
        JLabel pass = new JLabel("This is your 4-digits password");
        pass.setFont(new Font("RALEWAY", Font.BOLD, 13));
        pass.setBounds(280, 340, 570, 30);
        pass.setForeground(Color.WHITE);
        image.add(pass);
        
        JLabel servicesreq = new JLabel("SERVICES RECQUIRED");
        servicesreq.setFont(new Font("CASTELLAR", Font.BOLD, 16));
        servicesreq.setBounds(80, 375, 570, 30);
        servicesreq.setForeground(Color.BLACK);
        image.add(servicesreq);
        
        c1 = new JCheckBox("ATM CARD");
        c1.setBounds(135, 420, 150, 25);
        image.add(c1);
        
        c2 = new JCheckBox("INTERNET BANKING");
        c2.setBounds(380, 420, 200, 28);
        image.add(c2);
        
        c3 = new JCheckBox("E-STATEMENT");
        c3.setBounds(135, 460, 150, 25);
        image.add(c3);
        
        c4 = new JCheckBox("CHEQUE BOOK");
        c4.setBounds(380, 460, 200, 28);
        image.add(c4);
    
        ButtonGroup srgroup = new ButtonGroup();
        srgroup.add(c1);
        srgroup.add(c2);
        srgroup.add(c3);
        srgroup.add(c4);
   
        submit = new JButton("SUBMIT");
        submit.setBounds(500, 520, 100, 30);
        submit.addActionListener(this);
        image.add(submit);

        cancel = new JButton("CANCEL");
        cancel.setBounds(100, 520, 100, 30);
        cancel.addActionListener(this);
        image.add(cancel);

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setSize(720, 620);
        setLocation(300, 100);
        setVisible(true);
    }

    @Override // for the neccessary implementation of the defined methods
    public String getAccountType() {
        if (r1.isSelected()) return "SAVING ACCOUNT";
        if (r2.isSelected()) return "FIXED DEPOSIT ACCOUNT";
        if (r3.isSelected()) return "CURRENT ACCOUNT";
        if (r4.isSelected()) return "RECURRING DEPOSIT ACCOUNT";
        return null;
    }

    @Override
    public String getServicesRequired() {
        if (c1.isSelected()) return "ATM CARD";
        if (c2.isSelected()) return "INTERNET BANKING";
        if (c3.isSelected()) return "E-STATEMENT";
        if (c4.isSelected()) return "CHEQUE BOOK";
        return null;
    }

    @Override
    public String generateCardNumber() {
        return "31234322" + random;
    }

    @Override
    public String generatePin() {
        return String.format("%04d", new Random().nextInt(10000)); // generate 4-digit PIN
    }

    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == submit) {
            String acType = getAccountType();
            String servicesreq = getServicesRequired();
            
            if (acType == null || servicesreq == null) {
                JOptionPane.showMessageDialog(this, "Please select account type and services!");
                return;
            }
            
            // Generate card number and PIN
            String cardNumber = generateCardNumber();
            String pin = generatePin();

            // Show card number and pin
            JOptionPane.showMessageDialog(this, "Card Number: " + cardNumber);
            JOptionPane.showMessageDialog(this, "PIN: " + pin);

            // Save the information to a file
            String accountDetails = "Account Type: " + acType + "\nServices Required: " + servicesreq + "\nCard Number: " + cardNumber + "\nPIN: " + pin;
            saveInfo(accountDetails); // Call method to save data to a file
            setVisible(false);
            new Login();
        } else if (ae.getSource() == create) {
            new addAccounts();  
            setVisible(false);
        } else if (ae.getSource() == cancel){
           new Login();  
           setVisible(false); 
        }
    }

    private void saveInfo(String accountDetails) {
        try {
            // Using append mode to prevent overwriting data
            //ensures that every new registration is added without altering previous entries,
            FileWriter w = new FileWriter("Signup3.txt", true);
            BufferedWriter b = new BufferedWriter(w);

            // Writing user data to file
            b.write(accountDetails);
            b.newLine();
            b.write("-----------------------------------------------------"); // this is the append mode
            b.newLine();
            b.close();

            JOptionPane.showMessageDialog(null, "Information saved successfully!");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error occurred while saving: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Signup3();
    }
}
