package bank.management.system;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class Fast extends JFrame implements ActionListener {

    JButton exit, deposit, withdraw, fast, check, statement, pin;
    double balance = 10000.00;  // This will be updated based on the file
    double totalDeposited = 0.0; // Total deposited amount (from Deposit.txt)

    Fast() {
        super("Banking Management System");

        // read from the file
        readDepositsFromFile();

     
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/g.jpg"));
        Image i2 = i1.getImage().getScaledInstance(720, 620, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 720, 620);
        add(image);

        JLabel text = new JLabel("SELECT WITHDRAWAL AMOUNT");
        text.setFont(new Font("CASTELLAR", Font.BOLD, 18));
        text.setBounds(130, 115, 750, 50);
        text.setForeground(Color.BLACK);
        image.add(text);

     
        deposit = new JButton("Rs 100");
        deposit.setBounds(180, 240, 100, 30);
        deposit.addActionListener(this);
        image.add(deposit);

     
        withdraw = new JButton("Rs 500");
        withdraw.setBounds(320, 240, 100, 30);
        withdraw.addActionListener(this);
        image.add(withdraw);

     
        fast = new JButton("Rs 10000");
        fast.setBounds(180, 290, 100, 30);
        fast.addActionListener(this);
        image.add(fast);

   
        statement = new JButton("Rs 1500");
        statement.setBounds(320, 290, 100, 30);
        statement.addActionListener(this);
        image.add(statement);

     
        check = new JButton("Rs 5000");
        check.setBounds(320, 340, 100, 30);
        check.addActionListener(this);
        image.add(check);

  
        pin = new JButton("Rs 25000");
        pin.setBounds(180, 340, 100, 30);
        pin.addActionListener(this);
        image.add(pin);

       
        exit = new JButton("EXIT");
        exit.setBounds(500, 530, 100, 30);
        exit.addActionListener(this);
        image.add(exit);

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);
        setSize(720, 620);
        setLocation(300, 100);
        setUndecorated(true);
        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == exit) {
            setVisible(false);
            new Transaction().setVisible(true); 
        } else {
         
            JButton button = (JButton) ae.getSource();
            String amountStr = button.getText(); 

            // Extract the amount from the button text (remove "Rs " and convert to double)
            double amount = 0;
            try {
                amount = Double.parseDouble(amountStr.replace("Rs ", "")); 
            } // explicit
            catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid amount format!");
                return;
            }

            // Check if the withdrawal amount is greater than the total deposited amount
            if (amount > totalDeposited) {
                JOptionPane.showMessageDialog(null, "Insufficient balance! You cannot withdraw more than the deposited amount.");
            }else {
                // Check if the user has enough balance to withdraw the requested amount
                if (amount > balance) {
                    JOptionPane.showMessageDialog(null, "Insufficient balance!"); // Error message if balance is less
                } 
                else {
                    balance -= amount; // Subtract the amount from the balance
                    JOptionPane.showMessageDialog(null,
                    "Debited Amount: Rs " + amount + "\nRemaining Balance: Rs " + balance); // Success message with updated balance
                    setVisible(false);
                    new Transaction().setVisible(true);
                }
            }
        }
    }

    // Method to read total deposited amount from Deposit.txt
    private void readDepositsFromFile() {
        File file = new File("Deposit.txt");

        // Check if file exists
        if (!file.exists()) {
            JOptionPane.showMessageDialog(this, "Deposit file not found. Please ensure it's in the correct directory.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Amount Deposited")) {
                    // Extract the deposit amount and update the total deposited amount
                    String[] parts = line.split(":");
                    String amountStr = parts[1].split(",")[0].trim();
                    double amount = Double.parseDouble(amountStr);
                    totalDeposited += amount; // Add to total deposited amount
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading Deposit.txt: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new Fast(); // Start Fast withdrawal screen
    }
}
