
package bank.management.system.classes;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;

/**
 *
 * @author 3tee
 */
public class EmployeeManager {
    private List<EmployeeEntityClass> employees = new ArrayList<>();
    private final String filePath = "employeeDetails.txt";

    public EmployeeManager() {
        loadEmployeesFromFile();
    }

    // Load employee data from the file
    private void loadEmployeesFromFile() {
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] data = line.split(", ");
                if (data.length == 11) {
                    employees.add(new EmployeeEntityClass(data[0], data[5], data[6], data[10]));
                }
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error loading employee data: " + e.getMessage());
        }
    }

    // Get employee list
    public List<EmployeeEntityClass> getEmployees() {
        return employees;
    }

    // Find an employee by ID
    public EmployeeEntityClass findEmployeeByID(String empID) {
        for (EmployeeEntityClass emp : employees) {
            if (emp.getEmpID().equals(empID)) {
                return emp;
            }
        }
        return null;
    }

    // Delete an employee by ID and update the file
    public boolean deleteEmployee(String empID) {
        boolean isRemoved = employees.removeIf(emp -> emp.getEmpID().equals(empID));
        if (isRemoved) {
            return saveEmployeesToFile();
        }
        return false;
    }

    // Save updated employee data back to the file
    private boolean saveEmployeesToFile() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath))) {
            for (EmployeeEntityClass emp : employees) {
                String line = String.join(", ", 
                    emp.getName(), "-", "-", "-", "-", emp.getPhone(), emp.getEmail(), "-", "-", "-", emp.getEmpID());
                bw.write(line);
                bw.newLine();
            }
            return true;
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error updating employee data: " + e.getMessage());
            return false;
        }
    }
}

