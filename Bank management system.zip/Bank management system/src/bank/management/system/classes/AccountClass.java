/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank.management.system.classes;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;

/**
 *
 * @author 3tee
 */
public class AccountClass {
    private String firstName;
    private String lastName;
    private String fatherName;
    private String salary;
    private String address;
    private String phone;
    private String email;
    private String education;
    private String designation;
    private String cnic;
    private String accountId;

    // Constructor overloading(polymorphism)
    public AccountClass(String firstName, String lastName, String fatherName, String salary, String address, String phone, String email, String education, String designation, String cnic, String accountId) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.fatherName = fatherName;
        this.salary = salary;
        this.address = address;
        this.phone = phone;
        this.email = email;
        this.education = education;
        this.designation = designation;
        this.cnic = cnic;
        this.accountId = accountId;
    }

    // Getters and Setters (Encapsulation)
    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getFatherName() {
        return fatherName;
    }

    public String getSalary() {
        return salary;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getEducation() {
        return education;
    }

    public String getDesignation() {
        return designation;
    }

    public String getCnic() {
        return cnic;
    }

    public String getAccountId() {
        return accountId;
    }

    // Write Account details to file
    public void saveToFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("accountDetails.txt", true))) {
            writer.write(firstName + ", " + lastName + ", " + fatherName + ", " + salary + ", " + address + ", " + phone + ", " + email + ", " + education + ", " + designation + ", " + cnic + ", " + accountId);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
