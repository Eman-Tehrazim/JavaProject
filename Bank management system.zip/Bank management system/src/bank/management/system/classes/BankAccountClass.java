/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bank.management.system.classes;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class BankAccountClass {
    private static final String FILE_PATH = "Deposit.txt"; // method overloading

    // Method to calculate balance from the file
    public static double calculateBalance() throws IOException {
        File file = new File(FILE_PATH);

        // Check if the file exists
        if (!file.exists()) {
            throw new FileNotFoundException("Deposit file not found.");
        }

        double balance = 0.0;

        // Use try-with-resources for safe file handling
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line;

            // Loop through each line to calculate the balance
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Amount Deposited")) {
                    balance += extractAmount(line);
                } else if (line.startsWith("Amount Withdrawn")) {
                    balance -= extractAmount(line);
                }
            }
        }

        return balance;
    }

    // Helper method to extract the amount from a line
    public static double extractAmount(String line) throws NumberFormatException {
        Pattern pattern = Pattern.compile(":\\s*(\\d+(\\.\\d{1,2})?)");
        Matcher matcher = pattern.matcher(line);

        if (matcher.find()) {
            return Double.parseDouble(matcher.group(1));
        } else {
            throw new NumberFormatException("Invalid format: " + line);
        }
    }
}
