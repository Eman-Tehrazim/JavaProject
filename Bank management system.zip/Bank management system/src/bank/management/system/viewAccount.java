package bank.management.system;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;

public class viewAccount extends JFrame implements ActionListener {

    JTable table;
    DefaultTableModel model;
    JButton delete, back, update, print;

    viewAccount() {
        super("Banking Management System");

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/w.jpg"));
        Image i2 = i1.getImage().getScaledInstance(650, 500, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(1, 1, 650, 500);
        add(image);

        // Table for showing account details
        String[] columnNames = {"First Name", "Last Name", "Father Name", "Salary", "Address", "Phone", "Email", "Education", "Designation", "CNIC", "Account ID"};
        model = new DefaultTableModel(columnNames, 0);
        table = new JTable(model);
        table.setBounds(30, 40, 600, 300);
        JScrollPane sp = new JScrollPane(table);
        sp.setBounds(30, 40, 600, 300);
        image.add(sp);

        // Buttons for Delete, Update, Print, and Back
        delete = new JButton("DELETE");
        delete.setBounds(50, 400, 100, 30);
        delete.addActionListener(this);
        image.add(delete);

        update = new JButton("UPDATE");
        update.setBounds(200, 400, 100, 30);
        update.addActionListener(this);
        image.add(update);

        print = new JButton("PRINT");
        print.setBounds(350, 400, 100, 30);
        print.addActionListener(this);
        image.add(print);

        back = new JButton("NEXT");
        back.setBounds(500, 400, 100, 30);
        back.addActionListener(this);
        image.add(back);

        loadAccountData();

        setLayout(null);
        setSize(670, 500);
        setLocation(320, 100);
        setVisible(true);
    }

    private void loadAccountData() {
        try (BufferedReader br = new BufferedReader(new FileReader("accountDetails.txt"))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] rowData = line.split(", ");
                if (rowData.length == 11) {
                    model.addRow(rowData);
                }
            }
        } 
        catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == print) {
            try {
                table.print();
            } 
            catch (Exception e) {
                handleException(e);
            }
        }
        else if (ae.getSource() == delete) {
            deleteRow();
        } 
        else if (ae.getSource() == update) {
            updateRow();
        } 
        else if (ae.getSource() == back) {
            setVisible(false);
            new Transaction().setVisible(true); 
        }
    }

    private void deleteRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to delete.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this row?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (confirm == JOptionPane.YES_OPTION) {
            model.removeRow(selectedRow);
            saveTableData();
            JOptionPane.showMessageDialog(this, "Row deleted successfully.");
        }
    }

    private void updateRow() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a row to update.");
            return;
        }
        // this is used to represent the parent class where data will be shown
        String name = JOptionPane.showInputDialog(this, "Update Name", model.getValueAt(selectedRow, 0));
        if (name != null && !name.isEmpty()) {
            model.setValueAt(name, selectedRow, 0);
        }

        String fatherName = JOptionPane.showInputDialog(this, "Update Father Name", model.getValueAt(selectedRow, 1));
        if (fatherName != null && !fatherName.isEmpty()) {
            model.setValueAt(fatherName, selectedRow, 1);
        }

        String dob = JOptionPane.showInputDialog(this, "Update DOB", model.getValueAt(selectedRow, 2));
        if (dob != null && !dob.isEmpty()) { // value is not an empty string and user donot close without entering anything
            model.setValueAt(dob, selectedRow, 2);
        }

        String salary = JOptionPane.showInputDialog(this, "Update Salary", model.getValueAt(selectedRow, 3));
        if (salary != null && !salary.isEmpty()) {
            model.setValueAt(salary, selectedRow, 3);
        }

        String address = JOptionPane.showInputDialog(this, "Update Address", model.getValueAt(selectedRow, 4));
        if (address != null && !address.isEmpty()) {
            model.setValueAt(address, selectedRow, 4);
        }

        String phone = JOptionPane.showInputDialog(this, "Update Phone", model.getValueAt(selectedRow, 5));
        if (phone != null && !phone.isEmpty()) {
            model.setValueAt(phone, selectedRow, 5);
        }

        String email = JOptionPane.showInputDialog(this, "Update Email", model.getValueAt(selectedRow, 6));
        if (email != null && !email.isEmpty()) {
            model.setValueAt(email, selectedRow, 6);
        }

        String education = JOptionPane.showInputDialog(this, "Update Education", model.getValueAt(selectedRow, 7));
        if (education != null && !education.isEmpty()) {
            model.setValueAt(education, selectedRow, 7);
        }

        String designation = JOptionPane.showInputDialog(this, "Update Designation", model.getValueAt(selectedRow, 8));
        if (designation != null && !designation.isEmpty()) {
            model.setValueAt(designation, selectedRow, 8);
        }

        String cnic = JOptionPane.showInputDialog(this, "Update CNIC", model.getValueAt(selectedRow, 9));
        if (cnic != null && !cnic.isEmpty()) {
            model.setValueAt(cnic, selectedRow, 9);
        }

        String accountId = JOptionPane.showInputDialog(this, "Update Account ID", model.getValueAt(selectedRow, 10));
        if (accountId != null && !accountId.isEmpty()) {
            model.setValueAt(accountId, selectedRow, 10);
        }

        saveTableData();
        JOptionPane.showMessageDialog(this, "Row updated successfully.");
    }

    private void saveTableData() {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter("accountDetails.txt"))) {
            for (int i = 0; i < model.getRowCount(); i++) {
                StringBuilder sb = new StringBuilder();  //A StringBuilder is used to build a string for each row efficiently
                for (int j = 0; j < model.getColumnCount(); j++) {
                    sb.append(model.getValueAt(i, j)); // used to write new data in the string not rewrite the data
                    if (j < model.getColumnCount() - 1) sb.append(", "); // if the current row is not the last then add comma between string
                }
                bw.write(sb.toString()); // print the whole string
                bw.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void handleException(Exception e) {
        JOptionPane.showMessageDialog(this, "An error occurred: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void goBack() {
        setVisible(false);
    }

    public static void main(String[] args) {
        new viewAccount();
    }
}
