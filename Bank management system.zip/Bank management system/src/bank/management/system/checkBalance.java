package bank.management.system;

import bank.management.system.classes.BankAccountClass;
import java.awt.Color;
import java.awt.Font;
import java.awt.Image;
import javax.swing.*;
import java.io.*;
import java.util.regex.*;



public class checkBalance extends JFrame {
    JButton checkBalanceButton, exit;
    JLabel balanceLabel;

    checkBalance() {
        super("Banking Management System");

        setLayout(null);
        getContentPane().setBackground(Color.WHITE);

        // Background Image
        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("Icon/g.jpg"));
        Image i2 = i1.getImage().getScaledInstance(720, 620, Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel image = new JLabel(i3);
        image.setBounds(0, 0, 720, 620);
        add(image);

        // Check Balance Button
        checkBalanceButton = new JButton("CHECK BALANCE");
        checkBalanceButton.setBounds(200, 250, 200, 40);
        checkBalanceButton.setFont(new Font("Arial", Font.BOLD, 16));
        checkBalanceButton.addActionListener(e -> checkBalance());
        image.add(checkBalanceButton);

        // Balance Display Label
        balanceLabel = new JLabel("Current Balance: Rs 0.0");
        balanceLabel.setBounds(200, 320, 300, 40);
        balanceLabel.setFont(new Font("Arial", Font.PLAIN, 18));
        image.add(balanceLabel);

        // Exit Button
        exit = new JButton("EXIT");
        exit.setBounds(500, 530, 100, 30);
        exit.addActionListener(e -> {
            this.setVisible(false); // Close the current screen
            new Transaction().setVisible(true);
        });
        image.add(exit);

        // Frame Settings
        setSize(720, 620);
        setLocation(300, 100);
        setVisible(true);
    }

    // Method to check balance and update UI
    private void checkBalance() {
        try {
            double balance = BankAccountClass.calculateBalance();
            balanceLabel.setText("Current Balance: Rs " + balance);
        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(this, e.getMessage());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(this, "Error reading balance: " + e.getMessage());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid data format in Deposit file: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new checkBalance();
    }
}